using System.Web.Http;

namespace MyApp.Web.Controllers
{
    public class BaseController : ApiController
    {

    }
}